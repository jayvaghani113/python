# Program to print my name
print("jeni vaghani")
