# Define variables for different data types
integer_var = 42            # int
boolean_var = True          # bool
char_var = 'A'              # str (Python uses str for strings, not char)
float_var = 3.14            # float
double_var = 3.14159265359  # float (Python uses float for both float and double)

# Print variables on the console
print("Integer:", integer_var)
print("Boolean:", boolean_var)
print("Character:", char_var)
print("Float:", float_var)
print("Double:", double_var)



#output in sql