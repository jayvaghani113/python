# This is a single-line comment
print("Hello, World!")





"""
This is a multi-line comment.
It spans across multiple lines.
It can contain any text or explanation.
"""

print("Multi-line comment example")
