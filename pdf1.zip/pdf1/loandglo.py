# Global variable
my_variable = "Global"

def my_function():
    # Local variable with the same name as global variable
    my_variable = "Local"
    print("Inside function - Local variable:", my_variable)

# Call the function
my_function()

# Print global variable outside the function
print("Outside function - Global variable:", my_variable)
